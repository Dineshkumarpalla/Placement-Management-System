Placement Management System

	PMS is a Online Placement register Website. Student can registered by Login details (Backend by using PHP,SQL). It create a login Table with username and password in Database. It is redirected to the Home page it contain Navbar with All jobs Page,All Companys page,Admin Login page,Contact page. In All jobs page contain Available Jobs from  Different Companies and Different Roles. Students can register and apply for available job for particular company.
	
	Company want to freshers.Companies need to Register first and Post Job Notifications & apply links in PMS portal.Companies see Statuses. 
	I Use Technologies for Frontend (HTML, CSS, JavaScript, BootStrap)
